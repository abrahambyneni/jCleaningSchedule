#!/bin/bash
java -jar jCleaningSchedule.jar
